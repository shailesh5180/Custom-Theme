<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cloudstonetest
 */

get_header();
?>

	<div class="site-content" id="fullpage">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/home' );
	
			get_template_part( 'template-parts/home', 'about' );

			get_template_part( 'template-parts/home', 'founder' );

			get_template_part( 'template-parts/home', 'what-we-do' );
			
			get_template_part( 'template-parts/home', 'what-we-tabs' );
			
			get_template_part( 'template-parts/home', 'clients' );
			
			get_template_part( 'template-parts/home', 'testimonials' );

			get_template_part( 'template-parts/home', 'review' );
			
			get_template_part( 'template-parts/home', 'why-us' );
			
			get_template_part( 'template-parts/home', 'contact' );

			// If comments are open or we have at least one comment, load up the comment template.
			// if ( comments_open() || get_comments_number() ) :
			// 	comments_template();
			// endif;

		endwhile; // End of the loop.
		?>

	</div><!-- #main -->

<?php
// get_sidebar();
get_footer();
