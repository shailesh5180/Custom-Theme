  <?php //$group = get_field('what_we_tab2');?>
  <?php $heading8 = get_field('heading8');?>

<section class="what-we-tab-section section" id="what-we-tabs">
    <div class="container">
    
        <div class="what-we-tab-block">
            <div class="row">
                <div class="col-md-3">
                    <div class="block-title tab-left">
                        <h2><?= $heading8; ?></h2>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="block-content tab-right">
                        <div class="tab-main-box">
                         
                        <?php

                            if( have_rows('what_we_tab2') ){
                                 $i = 1; 
                              while ( have_rows('what_we_tab2') ) {
                               the_row();
                               
                                $service_details = get_sub_field('service_details');
                                ?>

 <div class="tab-box" id="tab-<?= $i; ?>" style="<?php if($i==1)echo 'display:block;'; ?>">
        <p><?php echo $service_details; ?></p>
    </div>

                                <?php

                                $i++;
                              }

                            }

                        ?>




                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-teaser container tab-left">
                <div class="tab-menu">
                    <ul>
                     <?php

                            if( have_rows('what_we_tab2') ){
                                 $i = 1; 
                              while ( have_rows('what_we_tab2') ) {
                               the_row();
                                $services = get_sub_field('services');
                                
                                ?>

 <li><a href="#" class="<?php if($i==1) echo 'active'; ?>" data-rel="tab-<?= $i; ?>"><?php echo $services; ?></a>
 </li>

                                <?php

                                $i++;
                              }

                            }

                        ?>



                    </ul>
                </div>
            </div>
        </div>

              
  </div>
</section>

