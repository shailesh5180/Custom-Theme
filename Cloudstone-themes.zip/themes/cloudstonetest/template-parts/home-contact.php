<?php $contact = get_field('contact');?>
<?php $heading3 = get_field('heading3');?>
<?php $email = get_field('email');?>
<?php $phone = get_field('phone');?>
<?php $address = get_field('address');?>
<?php $facebook_page_url = get_field('facebook_page_url');?>
<?php $instagram_account_url = get_field('instagram_account_url');?>
<?php $linkedin_url = get_field('linkedin_url');?>
<section class="contact-section left-overlay section" id="contact">
    <div class="container">
        <div class="contact-block">
            <div class="row">
                <div class="col-md-3">
                    <div class="contact-left">
                        <div class="block-title">
                            <h2><?= $heading3; ?></h2>
                        </div>
                        <div class="contact-info">
                            <div class="mail">
                                <label>Contact</label>
                                <h5><a href="mailto:<?= $email; ?>"><?= $email; ?></a></h5>
                            </div>
                            <div class="call">
                                <label>Call</label>
                                <h5><a href="tel:<?= $phone; ?>"><?= $phone; ?></a></h5>
                            </div>
                            <div class="address">
                                <label>Address</label>
                                <h5>
                                    <address>
                                        <?= $address; ?>
                                    </address>
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-9">
                   
                    <div class="block-content contact-right">
                        <div class="contact-form"><?php echo do_shortcode('[contact-form-7 id="10" title="Contact"]'); ?></div>
                        <div class="contact-footer">
                            <div class="copyright">
                                <small><?php //echo str_replace('%CURR_YEAR%', current_time('Y'), $contact['copyright_text']); ?></small>
                            </div>
                            <ul class="footer-social">
                                <li><a href="<?php echo $facebook_page_url; ?>" target="_blank"><img src="<?=get_template_directory_uri();?>/assets/images/facebook.svg" alt="footer-social" /></a></li>
                                <li><a href="<?php echo $instagram_account_url; ?>" target="_blank"><img src="<?=get_template_directory_uri();?>/assets/images/instram.svg" alt="footer-social" /></a></li>
                                <li><a href="<?php echo $linkedin_url; ?>" target="_blank"><img src="<?=get_template_directory_uri();?>/assets/images/linkedin.svg" alt="footer-social" /></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
