<section class="what-we-section section" id="what-we-do">
    <div class="section-bg-image p-image"></div>
    <div class="container">
        <?php $group = get_field('what_we_do'); ?>
        <?php $heading6 = get_field('heading6'); ?>
        <?php $sub_heading6 = get_field('sub_heading6'); ?>
        <?php $description6 = get_field('description6'); ?>
        <?php $heading7 = get_field('heading7'); ?>
        <?php $sub_heading7 = get_field('sub_heading7'); ?>
        <?php $photo = get_field('photo'); ?>
        <?php $daily_visitors = get_field('daily_visitors'); ?>
        <?php $pages_visited = get_field('pages_visited'); ?>
        
        <div class="what-we-block">
            <div class="row">
                <div class="col-md-6">
                    <div class="what-left">
                        <div class="desktop-what-we-do">
                            <div class="block-title">
                                <h2><?= $heading6; ?></h2>
                            </div>
                            <div class="block-content sub-heading">
                                <?= $sub_heading6; ?>
                            </div>
                        </div>
                        <div class="block-content mobile-space">
                            <?= $description6; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="what-right">
                        <div class="mobile-what-we-do">
                            <div class="block-title">
                            <h2><?= $heading7; ?></h2>
                        </div>
                        <div class="block-content sub-heading">
                            <?= $sub_heading7; ?>
                        </div>
                        </div>
                        <div class="page-visitor">
                            <img src="<?= $photo; ?>" loop="infinite" />
                        </div>
                        <div class="counter-block counters" id="inview-example">
                            <div class="counter-btn">
                                <div class="counter-txt">
                                    <span>Daily Visitors</span><span class="counter timer" data-count="<?=
                                    $daily_visitors; ?>"><?= $daily_visitors; ?></span>
                                </div>
                            </div>
                            <div class="counter-btn">
                                <div class="counter-txt">
                                    <span>Pages Visited</span><span class="counter timer" data-count="<?= 
                                    $pages_visited; ?>"><?= $pages_visited; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    
    </div>
</section>
