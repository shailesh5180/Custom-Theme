<?php $group = get_field('clients'); ?>
<?php $heading2 = get_field('heading2');?>
<?php $information2 = get_field('information2');?>
<?php $cta_link2 = get_field('cta_link2');?>

<section class="our-clients-section left-overlay section vertical-scrolling" id="our-clients">
    <div class="container">
        <div class="our-clients-block">
            <div class="row">
                <div class="col-md-3">
                    <div class="block-title client-left">
                        <h2><?= $heading2; ?></h2>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="block-content client-right">
                        <div class="row scrollable-content">
                            

                    <?php
                     if(have_rows('clientlogo')){
                        while (have_rows('clientlogo')) {
                           the_row();
                         ?>
                         <div class="col fade-bottom">
                            <div class="client-logo">
                                <img src="<?php echo get_sub_field('clogo'); ?>" alt="h-logo" class="hover-image"/>
                            </div>
                        </div>
                           
                        <?php
                        }
                     }
                    ?>


                        </div>
                        <div class="client-bottom-text">
                            <?= $information2; ?>
                            <?php if($cta_link2 != ''){?>
                            <div class="cta-black">
                                <a href="<?= $cta_link2; ?>" class="btn button" data-replace="GET STARTED"><span>GET STARTED</span></a>
                            </div>
                            <?php }?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>






