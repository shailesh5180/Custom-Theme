<?php $about = get_field('about');?>
<?php $heading1 = get_field('heading1');?>
<?php $sub_heading1 = get_field('sub_heading1');?>
<?php $information1 = get_field('information1');?>
<?php $expertises1 = get_field('expertises1');?>
<?php $cta_link1 = get_field('cta_link1');?>


<section class="about-section left-overlay section" id="about">
    <div class="container">
        <div class="about-block">
            <div class="row">
                <div class="col-md-3">
                    <div class="block-title left-about">
                        <h2><?= $heading1; ?></h2>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="block-content right-about fade">
                        <div class="about-intro fade-bottom">
                           
                                <h3><?= $sub_heading1; ?></h3>
                         
                            <?= $information1; ?>
                        </div>
                        <div class="expertise fade-top">
                            <h6>Expertise in</h6>
                            <ul>
                               
                                <li><?= $expertises1; ?></li>
                              

                            </ul>
                        </div>
                        <div class="about-cta cta-black fade-top">
                            <a href="<?= $cta_link1; ?>" class="btn button" data-replace="GET STARTED"><span>GET STARTED</span></a>
                        </div>
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



