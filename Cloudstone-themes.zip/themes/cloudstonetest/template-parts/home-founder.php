<?php $founder = get_field('founder'); ?>
<?php $heading4 = get_field('heading4'); ?>
<?php $description4 = get_field('description4'); ?>
<?php $cta_link4 = get_field('cta_link4'); ?>
<?php $profile_photo = get_field('profile_photo'); ?>
<?php $quote = get_field('quote'); ?>

<section class="who-we-section left-overlay section" id="founder">
    <div class="container">
        <div class="who-we-block">
            <div class="row">
                <div class="col-md-6">
                    <div class="block-title left-weare">
                        <h2><?= $heading4; ?></h2>
                    </div>
                    <div class="block-content left-weare">
                        <?= $description4; ?>
                        <?php if($cta_link4 != ''){?>
                        <div class="who-we-cta cta-black">
                            <a href="<?= $cta_link4; ?>" class="btn button" data-replace="GET STARTED"><span>GET STARTED</span></a>
                        </div>
                        <?php }?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="block-image right-whoare">
                        
                        <img src="<?= $profile_photo; ?>" alt="we-image" />
                        <blockquote>
                            <p><?= $quote; ?></p>
                        </blockquote>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

