
<?php $heading5 = get_field('heading5'); ?>


<section class="review-section section bg-cover" id="review" style="background: url(<?php echo get_template_directory_uri(); ?>/assets/images/main-banner.jpg) center center no-repeat;">



    <div class="container">
        <div class="block-title fade-top">
            <h2><?= $heading5; ?></h2>
        </div>
    </div>
 <div class="review-block">
    <div class="row">
        <div class="col-md-4">

        </div>
        <div class="col-md-8">
               
            <div class="block-content review-right">
                <!-- <div class="drag-img">Drag</div> -->
                <div class="owl-carousel owl-theme review-slider" id="review-slider">
                  

             <?php
             if(have_rows('reviews5')){
                 $i = 1; 
                while(have_rows('reviews5')){
                    the_row();
                   
                                             
                    ?>
                    <div class="item">
                    <div class="review-items">
                        <div class="review-content">
                           
                            <p><?php echo get_sub_field('information5');  ?></p>
                        </div>
                        <div class="review-descreption">
                            <div class="author-image">

                                <img src="<?php echo get_sub_field('client_photo5'); ?>" alt="review" />
                            </div>
                            <div class="author-position">
                                <h5><?php echo get_sub_field('client_name5'); ?></h5>
                                <p><?php echo get_sub_field('position_company5'); ?></p>
                            </div>
                        </div>
                    </div>
                    </div>

                    <?php
                     $i++;
                }
             }

            ?>


                </div>
            </div>
        </div>
    </div>
</div>
  </section>




