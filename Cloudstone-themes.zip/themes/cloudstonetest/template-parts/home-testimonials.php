
<?php //$testimonials = get_field('testimonials');?>
<?php $sub_heading5 = get_field('sub_heading5');?>
<?php $cta_link5 = get_field('cta_link5');?>




<section class="testimonials-section bg-cover section"  id="testimonials" style="background: url(<?= get_template_directory_uri(); ?>/assets/images/testimonial-bg.jpg) no-repeat center;">
   
    <div class="banner-content">
        <h2 class="fade-bottom"><?= $sub_heading5; ?><strong>AED 6 Million</strong> in ad spend</h2>
        <?php if($cta_link5 != ''){?><a href="<?= $cta_link5; ?>" class="btn button fade-bottom" data-replace="GET STARTED"><span>GET STARTED</span></a><?php }?>
    </div>
  
</section>

