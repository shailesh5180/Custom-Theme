<?php $why_us = get_field('why_us');?>
<?php $heading9 = get_field('heading9');?>
<?php $sub_heading9 = get_field('sub_heading9');?>
<section class="why-section left-overlay section" id="why-us">
	<div class="container">
		<div class="why-block">
			<div class="row">
				<div class="col-md-3">
					<div class="block-title why-left">
						<h2><?= $heading9; ?></h2>
					</div>
				</div>
				<div class="col-md-9">
					<div class="block-content why-right">
						<?php if($sub_heading9 != ''){?>
							<div class="why-intro">
								<h3><?= $sub_heading9; ?></h3>
							</div>
						<?php }?>
						<div class="why-list">
							<ul>
								<?php
								 if(have_rows('features')){
								 	while (have_rows('features')) {
								 	   the_row();
								 	 ?>
								 		<li>
											<h5><?php echo get_sub_field('features_label'); ?></h5>
										</li>
								 	<?php
								 	}
								 }
								?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>