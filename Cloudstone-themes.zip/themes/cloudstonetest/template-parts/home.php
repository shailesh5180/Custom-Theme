<section class="banner-section section" style="background-image: url(<?=get_template_directory_uri();?>/assets/images/main-banner.jpg);">
    <div class="banner-after" style="background: url(<?=get_template_directory_uri();?>/assets/images/mountain.png) no-repeat bottom;"></div>
    <div class="banner-content">
        <?php the_content();?>
        <a href="#about" class="btn button"><span>GET STARTED</span></a>
    </div>
</section>
