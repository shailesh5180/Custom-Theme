<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cloudstonetest
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="icon" href="assets/images/favicon.png" type="image/png">
	<link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Gruppo&display=swap" rel="stylesheet">
	 <title><?php bloginfo( 'name' ); ?></title>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
 <div class="site-wrapper" id="page">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'cloudstonetest' ); ?></a>
  
	<header id="masthead" class="site-header">
		<div class="site-branding">
			<?php
			the_custom_logo();
			if ( is_front_page() && is_home() ) :
				?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php
			else :
				?>
				<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
				<?php
			endif;
			?>
		</div><!-- .site-branding -->

	<!--	<nav id="site-navigation" class="main-navigation">
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php //esc_html_e( 'Primary Menu', 'cloudstonetest' ); ?></button>-->
			<?php
			/*wp_nav_menu(
				array(
					'theme_location' => 'left-menu',
					'menu_id'        => 'menu',
				)
			);*/
			?>

		<!-- </nav>#site-navigation -->




		      <div class="container">
                <div class="navigation">
                    <div class="left-menu">
             <?php
			wp_nav_menu(
				array(
					'theme_location' => 'left-menu',
					'menu_id'        => 'menu',
				)
			);
			?>
                        <!-- <ul class="menu">
                            <li><a href="#about">Who We Are</a></li>
                            <li><a href="#what-we-do">What We Do</a></li>
                            <li><a href="#our-clients">Our Clients</a></li>
                        </ul> -->
                    </div>
                    <div class="logo">
                        <a href="#home">Cloudstons</a>
                    </div>
                    <div class="right-menu">
            <?php
			wp_nav_menu(
				array(
					'theme_location' => 'right-menu',
					'menu_id'        => 'menu',
				)
			);
			?>
                        <!-- <ul class="menu">
                            <li><a href="#testimonials">Testimonials</a></li>
                            <li><a href="#contact">Get in touch</a></li>
                        </ul> -->
                    </div>
                    <div class="humberg-menu">
                        <!-- <img src="assets/images/humberg.svg" alt="menu-icon" /> -->
                    </div>
                    <div class="mobile-menu">
            <?php
			wp_nav_menu(
				array(
					'theme_location' => 'mobile-menu',
					'menu_id'        => 'menu',
				)
			);
			?>
                       <!--  <ul class="menu">
                            <li><a href="#about">Who We Are</a></li>
                            <li><a href="#what-we-do">What We Do</a></li>
                            <li><a href="#our-clients">Our Clients</a></li>
                        </ul>
                        <ul class="menu">
                            <li><a href="#about">Who We Are</a></li>
                            <li><a href="#what-we-do">What We Do</a></li>
                            <li><a href="#our-clients">Our Clients</a></li>
                        </ul> -->
                    </div>
                </div>
            </div>
	</header><!-- #masthead -->


