<div class="sidebar">
	<?php if ( is_active_sidebar( 'blog-sidebar' ) ) {
		dynamic_sidebar( 'blog-sidebar' );
	} ?>
</div>